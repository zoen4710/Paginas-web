<?php
$titulo = 'Listado de Productos';
include '_header.php';



include '_footer.php';
?>