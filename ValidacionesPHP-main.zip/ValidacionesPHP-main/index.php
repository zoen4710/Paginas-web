<?php
$titulo = 'Inicio';
include '_header.php';
?>


<?php
include '_footer.php';
?>